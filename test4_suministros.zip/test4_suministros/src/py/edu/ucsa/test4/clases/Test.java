package py.edu.ucsa.test4.clases;

public class Test {

	public static void main(String[] args) {
		Lectura.tomarDatosLecturas();

	}

}
