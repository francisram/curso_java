package py.edu.ucsa.test4.interfaces;

public interface Calculable {
	public void calcularConsumo();

}
