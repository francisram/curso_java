package py.edu.ucsa.tte.interfaces;

public interface Validable {
	public boolean validar(int horaMinuto);
}
