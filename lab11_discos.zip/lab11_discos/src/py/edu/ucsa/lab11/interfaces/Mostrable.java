package py.edu.ucsa.lab11.interfaces;

public interface Mostrable {
	void mostrarInfo();
}
