package py.edu.ucsa.lab11.interfaces;

public interface Borrable extends Mostrable {
	void borrar();
}
