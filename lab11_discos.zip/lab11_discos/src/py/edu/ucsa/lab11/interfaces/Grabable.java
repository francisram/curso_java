package py.edu.ucsa.lab11.interfaces;

public interface Grabable extends Mostrable {
	void grabar();
}
